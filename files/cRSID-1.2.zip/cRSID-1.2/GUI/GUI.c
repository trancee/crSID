//anti-aliased GUI library by Hermit (for SDL)

typedef unsigned char byte; //typedef uint8_t byte;
typedef unsigned short word; //typedef uint16_t word;
typedef unsigned int  dword; //typedef uint32_t word;

enum Defaults { WINWIDTH=320, WINHEIGHT=240,
                BYTES_PER_PIXEL=4, BITS_PER_PIXEL=(BYTES_PER_PIXEL*8),
                ERRORCODE_DEFAULT=-1
              };

#include <math.h>

#include "layout.c"


static char *mouse_xpm[] = {
"32 32 3 1 0 0",
"0	c #000000",
"1	c #FFFFFF",
" 	c None",
"00                              ",
"010                             ",
"01100                           ",
"011100                          ",
"0111100                         ",
"01110100                        ",
"010111100                       ",
"0111111100                      ",
"01111111100                     ",
"01111111100                     ",
"01111111100                     ",
"01111111000                     ",
"0011111000                      ",
" 00000100                       ",
"  000010                        ",
"      010                       ",
"      010                       ",
"       01                       ",
"         1                      ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                "
};

#include "graphics/cRSID-icon-16x16.xpm"


// SDL interprets each pixel as a 32-bit number, so our masks must depend on the endianness (byte order) of the machine
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
 Uint32 rmask = 0xff000000, gmask = 0x00ff0000, bmask = 0x0000ff00, amask = 0x000000ff;
#else
 Uint32 rmask = 0x000000ff, gmask = 0x0000ff00, bmask = 0x00ff0000, amask = 0xff000000;
#endif

static unsigned char icon_pixels[16*16*32]; static SDL_Surface *cRSID_Icon;
static SDL_Cursor *MouseCursor;
static SDL_Event Event;
static char ExitSignal=0;
static byte FirstDraw=1;


void XPMtoPixels(char* source[], unsigned char* target) {
 int i,j,k,sourceindex,targetindex,width,height,colours,charpix,transpchar=0xff;
 unsigned int colr[256],colg[256],colb[256];
 unsigned char colchar[256], colcode,colindex;
 sscanf(source[0],"%d %d %d %d",&width,&height,&colours,&charpix);
 for (i=0;i<colours;i++) {
  if (sscanf(source[1+i],"%c%*s #%2X%2X%2X",&colchar[i],&colr[i],&colg[i],&colb[i])!=4) transpchar=colchar[i];
 }
 for (i=0;i<height;i++) {
  for (j=0;j<width;j++) {
   sourceindex=(i*width+j); colcode=source[colours+1+i][j]; for(k=0;k<colours;k++) if (colcode==colchar[k]) break; colindex=k;
   targetindex=(i*width+j)*4;
   target[targetindex+0] = colr[colindex]; //Red
   target[targetindex+1] = colg[colindex]; //Green
   target[targetindex+2] = colb[colindex]; //Blue
   target[targetindex+3] = (colcode==transpchar)?0x00:0xff ;//Aplha - 0:fully transparent...0xFF:fully opaque
 }}
}


static SDL_Cursor *init_system_cursor(char *image[]) { // Create a new SDL mouse-cursor from an XPM
 int i, row, col; Uint8 data[4*32]; Uint8 mask[4*32]; int hot_x, hot_y;
 for ( i=-1, row=0; row<32; ++row ) {
  for ( col=0; col<32; ++col ) {
   if ( col % 8 ) { data[i] <<= 1; mask[i] <<= 1; }
   else { ++i; data[i] = mask[i] = 0; }
   switch (image[4+row][col]) {
    case '0': data[i] |= 0x01; mask[i] |= 0x01; break;
    case '1': mask[i] |= 0x01; break;
    case ' ': break;
 }}}
 hot_x=hot_y=0; //sscanf(image[4+row], "%d,%d", &hot_x, &hot_y);
 return SDL_CreateCursor(data, mask, 32, 32, hot_x, hot_y);
}


void initGUI() {
 if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
  fprintf(stderr, "Couldn't initialize SDL-Video: %s\n",SDL_GetError()); exit(-1);
 }

 SDL_WM_SetCaption("cRSID-"VERSION" C64 SID-music player","cRSID-"VERSION);

 XPMtoPixels(cRSID_xpm, icon_pixels);
 cRSID_Icon = SDL_CreateRGBSurfaceFrom( (void*)icon_pixels, 16, 16, 32, 16*4, rmask, gmask, bmask, amask );
 SDL_WM_SetIcon(cRSID_Icon, NULL);

 MouseCursor = init_system_cursor(mouse_xpm); SDL_SetCursor(MouseCursor);

 Screen = SDL_SetVideoMode( WINWIDTH, WINHEIGHT, BITS_PER_PIXEL, SDL_SWSURFACE); //|SDL_RESIZABLE|SDL_HWACCEL|SDL_ANYFORMAT); //SDL_HWSURFACE|SDL_HWACCEL|SDL_ANYFORMAT); //SDL_OPENGL|SDL_OPENGLBLIT|SDL_DOUBLEBUF|SDL_FULLSCREEN|SDL_SWSURFACE|SDL_RESIZABLE);
 if(Screen==NULL) { printf("Couldn't create SDL window: %s",SDL_GetError()); exit(ERRORCODE_DEFAULT); }

}


void drawGUI (cRSID_C64instance *C64) {
 static word angle=0;
 Pixels = Screen->pixels; //WinWidth=Screen->w; WinHeight=Screen->h;

 if (FirstDraw) { FirstDraw=0; drawOnce(C64); SDL_UpdateRect( Screen, 0, 0, WINWIDTH, SID1INFO_Y ); } //SDL_FillRect(Screen, &Screen->clip_rect, MARGIN_COLOR);

 { drawRepeatedly(C64); SDL_UpdateRect( Screen, 0, FRAMESPEEDINFO_Y, WINWIDTH, WINHEIGHT-FRAMESPEEDINFO_Y ); }

 //SDL_UpdateRect( Screen, 0, 0, WINWIDTH, WINHEIGHT ); //WinWidth, WinHeight );
}


void mainLoop (cRSID_C64instance *C64) {
 enum Periods { INPUTSCAN_PERIOD=5, FRAMETIME=20, //ms
                SCREENUPDATE_PERIOD = (FRAMETIME/INPUTSCAN_PERIOD) };

 static byte i, ScreenUpdateCounter=0, PrevPressedButton=0; static const SDL_VideoInfo *VideoInfo;
 static Uint8* KeyStates; static int MouseX, MouseY; static Uint32 MouseButtonStates;

 void startSubTune(byte subtune) {
  cRSID_pauseSIDtune(); cRSID_initSIDtune(C64,C64->SIDheader,subtune); C64->PlaybackSpeed=1; C64->Paused=0; cRSID_playSIDtune();
  FirstDraw=1;
 }

 while(!ExitSignal) {
  while (SDL_PollEvent(&Event)) {
   if (Event.type == SDL_QUIT) { ExitSignal=1; }
   else if(Event.type==SDL_KEYDOWN) {
    switch (Event.key.keysym.sym) {
     case SDLK_ESCAPE: ExitSignal=1; break;
     case SDLK_SPACE: C64->PlaybackSpeed=1; C64->Paused^=1; if(C64->Paused) cRSID_pauseSIDtune(); else cRSID_playSIDtune(); break;
     case SDLK_1: startSubTune(1); break;
     case SDLK_2: startSubTune(2); break;
     case SDLK_3: startSubTune(3); break;
     case SDLK_4: startSubTune(4); break;
     case SDLK_5: startSubTune(5); break;
     case SDLK_6: startSubTune(6); break;
     case SDLK_7: startSubTune(7); break;
     case SDLK_8: startSubTune(8); break;
     case SDLK_9: startSubTune(9); break;
     case SDLK_RETURN: startSubTune(C64->SubTune); break; //PressedButton=1; break;
     case SDLK_PLUS: startSubTune(++C64->SubTune); break;
     case SDLK_MINUS: startSubTune(--C64->SubTune); break;
     case SDLK_UP: if (C64->MainVolume+32<255) C64->MainVolume+=32; else C64->MainVolume=255; break;
     case SDLK_DOWN: if (C64->MainVolume-32>0) C64->MainVolume-=32; else C64->MainVolume=0; break;
    }
   }
   else if (Event.type == SDL_MOUSEBUTTONDOWN) {
    if (Event.button.button==SDL_BUTTON_LEFT) {
     if (BUTTONS_Y <= Event.button.y && Event.button.y < BUTTONS_Y+PUSHBUTTON_HEIGHT) {
      for(i=0;i<PUSHBUTTON_AMOUNT;++i)
       if (PushButtonX[i]<=Event.button.x && Event.button.x < PushButtonX[i]+PUSHBUTTON_WIDTH) { PressedButton=i+1; break; }
     }
    }
    else if (Event.button.button==SDL_BUTTON_WHEELUP) { if (C64->MainVolume+8<255) C64->MainVolume+=8; else C64->MainVolume=255; }
    else if (Event.button.button==SDL_BUTTON_WHEELDOWN) { if (C64->MainVolume-8>0) C64->MainVolume-=8; else C64->MainVolume=0; }
   }

  }


  if (PressedButton && PressedButton!=PrevPressedButton) {
   switch (PressedButton) {
    case 1: startSubTune(C64->SubTune); break;
    case 2: C64->PlaybackSpeed=1; C64->Paused^=1; if(C64->Paused) cRSID_pauseSIDtune(); else cRSID_playSIDtune(); break;
    case 4: startSubTune(--C64->SubTune); break;
    case 5: startSubTune(++C64->SubTune); break;
    case 6: C64->Stereo^=1; break;
    case 7:
     if (C64->SelectedSIDmodel==8580) C64->SelectedSIDmodel=6581;
     else if (C64->SelectedSIDmodel==6581) C64->SelectedSIDmodel=8580;
     else {
      if (C64->SID[1].ChipModel==8580) C64->SelectedSIDmodel=6581;
      else if (C64->SID[1].ChipModel==6581) C64->SelectedSIDmodel=8580;
     }
     C64->SID[1].ChipModel = C64->SID[2].ChipModel = C64->SID[3].ChipModel = C64->SID[4].ChipModel = C64->SelectedSIDmodel;
     break;
   }
   //if (PressedButton!=3) PressedButton=0;
  }
  PrevPressedButton=PressedButton;
  MouseButtonStates = SDL_GetMouseState(&MouseX,&MouseY);
  if ((MouseButtonStates & SDL_BUTTON_LMASK)==0) PressedButton=0;


  KeyStates = SDL_GetKeyState(NULL);
  if ( (KeyStates[SDLK_TAB] && !KeyStates[SDLK_LALT]) || KeyStates[SDLK_BACKQUOTE] || KeyStates[SDLK_END] || KeyStates[SDLK_RIGHT] ) {
   C64->PlaybackSpeed=FFWD_SPEED; PressedButton=3;
  }
  else if (PressedButton==3) C64->PlaybackSpeed=FFWD_SPEED;
  else C64->PlaybackSpeed=1;


  if(ScreenUpdateCounter<SCREENUPDATE_PERIOD) ++ScreenUpdateCounter;  else { ScreenUpdateCounter=0; drawGUI(C64); }

  SDL_Delay(INPUTSCAN_PERIOD);
 }
}

