
enum WindowTheme { MARGIN_COLOR=0x202020, BACKGROUND_COLOR=MARGIN_COLOR, MARGIN_THICKNESS=4, FIELD_CHARCOUNT_MAX=32 };


#include "widgets.c"


static unsigned char* PushButtonTexts[] = { "\x1E\x1F", "\x1D"/*"1F"*/, "\x1F\x1F", "<", ">",   "ste" , "SID" };
static byte PushButtonSeparation[] =      {      0,       0,                  0,     2,   2 ,     4   ,   4   };
static word PushButtonX[] =               {      0,       0,                  0,     0,   0,      0,      0,  };
static byte PressedButton=0;

enum ButtonLayout { PUSHBUTTON_AMOUNT = sizeof(PushButtonTexts) / sizeof(char*),
                    PUSHBUTTON_HEIGHT = 30, PUSHBUTTON_WIDTH=28, BUTTONS_Y=WINHEIGHT-MARGIN_THICKNESS*2-PUSHBUTTON_HEIGHT,
                    PUSHBUTTON_SPACING=5, PUSHBUTTON_PADDING=(PUSHBUTTON_WIDTH+PUSHBUTTON_SPACING)
                  };


//Fields (blocks) & Separators
//enum FieldLayout { };


unsigned char* valueToHexString (word value) {
 static unsigned char String[10];
 sprintf(String,"$%4.4X",value);
 return String;
}


 enum Layout {
               FIELDTITLE_X=MARGIN_THICKNESS, FIELDTITLE_WIDTH=50, TEXTFIELD_PADDING=22,
               AUTHOR_Y=MARGIN_THICKNESS, TITLE_Y=(AUTHOR_Y+TEXTFIELD_PADDING), RELEASEINFO_Y=(TITLE_Y+TEXTFIELD_PADDING),
               TEXTFIELD_X=(MARGIN_THICKNESS+FIELDTITLE_WIDTH), TEXTFIELD_WIDTH=(WINWIDTH-MARGIN_THICKNESS-TEXTFIELD_X),
               LOADINFO_X=FIELDTITLE_X, LOADINFO_Y=(RELEASEINFO_Y+TEXTFIELD_PADDING+MARGIN_THICKNESS),
               VALUETITLE_WIDTH=32, VALUEFIELD_WIDTH=50, VALUEFIELD_PADDING=(VALUETITLE_WIDTH+VALUEFIELD_WIDTH+4),
               ENDINFO_X=(LOADINFO_X+VALUEFIELD_PADDING), ENDINFO_Y=LOADINFO_Y,
               SIZEINFO_X=(ENDINFO_X+VALUEFIELD_PADDING), SIZEINFO_Y=LOADINFO_Y,
                SIZEINFO_WIDTH=(WINWIDTH-MARGIN_THICKNESS-(SIZEINFO_X+VALUETITLE_WIDTH)),
               INITINFO_X=FIELDTITLE_X, INITINFO_Y=(SIZEINFO_Y+TEXTFIELD_PADDING),
               PLAYINFO_X=(INITINFO_X+VALUEFIELD_PADDING), PLAYINFO_Y=INITINFO_Y,
               IRQINFO_X=(PLAYINFO_X+VALUEFIELD_PADDING+4), IRQINFO_Y=PLAYINFO_Y, IRQINFO_WIDTH=25,
               SUBTUNEINFO_X=(IRQINFO_X+IRQINFO_WIDTH), SUBTUNEINFO_Y=INITINFO_Y,
                SUBTUNEINFO_WIDTH = ( WINWIDTH-MARGIN_THICKNESS-(SUBTUNEINFO_X+VALUETITLE_WIDTH) ),
               STANDARDINFO_X=FIELDTITLE_X, SPEEDINFO_Y=(INITINFO_Y+TEXTFIELD_PADDING+MARGIN_THICKNESS),
                SPEEDTITLE_WIDTH=56, SPEEDINFOFIELD_WIDTH=42, SPEEDINFO_PADDING=(SPEEDTITLE_WIDTH+SPEEDINFOFIELD_WIDTH+MARGIN_THICKNESS),
               TIMERINFO_X=(STANDARDINFO_X+SPEEDINFO_PADDING-2), TIMERINFO_Y=SPEEDINFO_Y, TIMERTITLE_WIDTH=50,
               FRAMESPEEDINFO_X=(TIMERINFO_X+TIMERTITLE_WIDTH+SPEEDINFOFIELD_WIDTH+MARGIN_THICKNESS), FRAMESPEEDINFO_Y=SPEEDINFO_Y, FRAMESPEEDTITLE_WIDTH=74,
               SID1INFO_X=FIELDTITLE_X, SID1INFO_Y=(SPEEDINFO_Y+TEXTFIELD_PADDING+MARGIN_THICKNESS), SIDINFOFIELD_WIDTH=107,
                SCOPE1_X=(SID1INFO_X+VALUETITLE_WIDTH+SIDINFOFIELD_WIDTH+MARGIN_THICKNESS)-1, SCOPE1_Y=SID1INFO_Y, SCOPE_WIDTH=14,
                SCOPE_HEIGHT=(TEXTFIELD_PADDING-MARGIN_THICKNESS), SCOPE_BGCOLOR=0x081810, SCOPE_FGCOLOR=0x60A080,
               SID2INFO_X=(WINWIDTH-(SIDINFOFIELD_WIDTH+FIELDTITLE_X+VALUETITLE_WIDTH)), SID2INFO_Y=SID1INFO_Y,
                SCOPE2_X=(SID2INFO_X-SCOPE_WIDTH-MARGIN_THICKNESS)+5, SCOPE2_Y=SCOPE1_Y,
               SID3INFO_X=FIELDTITLE_X, SID3INFO_Y=SID1INFO_Y+TEXTFIELD_PADDING,
                SCOPE3_X=SCOPE1_X, SCOPE3_Y=SID3INFO_Y,
               SID4INFO_X=SID2INFO_X, SID4INFO_Y=SID3INFO_Y,
                SCOPE4_X=SCOPE2_X, SCOPE4_Y=SCOPE3_Y,
               CONTROLS_X=MARGIN_THICKNESS, CONTROLS_Y=(SID3INFO_Y+TEXTFIELD_PADDING+MARGIN_THICKNESS)+5,
               POTMETER_WIDTH=POTMETER_RADIUS+10, POTMETER_X=(WINWIDTH-MARGIN_THICKNESS-POTMETER_WIDTH), POTMETER_Y=CONTROLS_Y+15,
               PLAYTIME_WIDTH=44, PLAYTIME_X=(POTMETER_X-POTMETER_WIDTH/2-MARGIN_THICKNESS-PLAYTIME_WIDTH-3), PLAYTIME_Y=(CONTROLS_Y+8)
             };



void drawOnce (cRSID_C64instance *C64) {

 static unsigned char String[32]; static word Tmp;
 static SDL_Rect BackGroundRectangle;


 BackGroundRectangle.x=BackGroundRectangle.y=0; BackGroundRectangle.w=WINWIDTH; BackGroundRectangle.h=SID1INFO_Y;
 SDL_FillRect(Screen, &BackGroundRectangle, MARGIN_COLOR); //SDL_FillRect(Screen, &Screen->clip_rect, MARGIN_COLOR);


 drawFieldTitle( FIELDTITLE_X, AUTHOR_Y, FIELDTITLE_WIDTH, "Author:" );
  drawTextField( TEXTFIELD_X, AUTHOR_Y, TEXTFIELD_WIDTH, C64->SIDheader->Author );

 drawFieldTitle( FIELDTITLE_X, TITLE_Y, FIELDTITLE_WIDTH, "Title:");
  drawTextField( TEXTFIELD_X, TITLE_Y, TEXTFIELD_WIDTH, C64->SIDheader->Title );

 drawFieldTitle( FIELDTITLE_X, RELEASEINFO_Y, FIELDTITLE_WIDTH, "Release:");
  drawTextField( TEXTFIELD_X, RELEASEINFO_Y, TEXTFIELD_WIDTH, C64->SIDheader->ReleaseInfo );


 drawHorizontalSeparator ( MARGIN_THICKNESS, LOADINFO_Y-MARGIN_THICKNESS-1, WINWIDTH-MARGIN_THICKNESS);


 drawFieldTitle( LOADINFO_X, LOADINFO_Y, VALUETITLE_WIDTH, "Load:");
  drawTextField( LOADINFO_X+VALUETITLE_WIDTH, LOADINFO_Y, VALUEFIELD_WIDTH, valueToHexString(C64->LoadAddress) );

 drawFieldTitle( ENDINFO_X, ENDINFO_Y, VALUETITLE_WIDTH, "End:");
  drawTextField( ENDINFO_X+VALUETITLE_WIDTH, ENDINFO_Y, VALUEFIELD_WIDTH, valueToHexString(C64->EndAddress) );

 drawFieldTitle( SIZEINFO_X, SIZEINFO_Y, VALUETITLE_WIDTH, "Size:");
  Tmp=C64->EndAddress-C64->LoadAddress; sprintf( String, "$%4.4X (%d)", Tmp, Tmp );
  drawTextField( SIZEINFO_X+VALUETITLE_WIDTH, SIZEINFO_Y, SIZEINFO_WIDTH, String );

 drawFieldTitle( INITINFO_X, INITINFO_Y, VALUETITLE_WIDTH, "Init:");
  drawTextField( INITINFO_X+VALUETITLE_WIDTH, INITINFO_Y, VALUEFIELD_WIDTH, valueToHexString(C64->InitAddress) );

 drawFieldTitle( PLAYINFO_X, PLAYINFO_Y, VALUETITLE_WIDTH, "Play:");
  drawTextField( PLAYINFO_X+VALUETITLE_WIDTH, PLAYINFO_Y, VALUEFIELD_WIDTH+5,
                 (!C64->RealSIDmode)? valueToHexString(C64->PlayAddress) : (unsigned char*) "RealSID" );
   if (C64->SIDheader->PlayAddressH==0 && C64->SIDheader->PlayAddressL==0) {
    setFontSize(8); drawString(IRQINFO_X,IRQINFO_Y+4,"(IRQ)");
   }

 drawFieldTitle( SUBTUNEINFO_X, SUBTUNEINFO_Y, VALUETITLE_WIDTH, "Subtune:" );
  sprintf( String, "%d / %d", C64->SubTune, C64->SIDheader->SubtuneAmount );
  drawCenteredTextField( SUBTUNEINFO_X+VALUETITLE_WIDTH, SUBTUNEINFO_Y, SUBTUNEINFO_WIDTH, String );


 drawHorizontalSeparator ( MARGIN_THICKNESS, SPEEDINFO_Y-MARGIN_THICKNESS-1, WINWIDTH-MARGIN_THICKNESS);


 drawFieldTitle( STANDARDINFO_X, SPEEDINFO_Y, SPEEDTITLE_WIDTH, "Standard:");
  drawCenteredTextField( STANDARDINFO_X+SPEEDTITLE_WIDTH, SPEEDINFO_Y, SPEEDINFOFIELD_WIDTH, C64->VideoStandard? "PAL":"NTSC" );

 drawFieldTitle( TIMERINFO_X, TIMERINFO_Y, TIMERTITLE_WIDTH, "TimerIC:");
  drawCenteredTextField( TIMERINFO_X+TIMERTITLE_WIDTH, TIMERINFO_Y, SPEEDINFOFIELD_WIDTH, C64->RealSIDmode? "?" : (C64->TimerSource? "CIA":"VIC") );

 drawFieldTitle( FRAMESPEEDINFO_X, FRAMESPEEDINFO_Y, FRAMESPEEDTITLE_WIDTH, "FrameSpeed:"); //can change during playback (refresh regularly)


 drawHorizontalSeparator ( MARGIN_THICKNESS, SID1INFO_Y-MARGIN_THICKNESS-1, WINWIDTH-MARGIN_THICKNESS);


}


void drawRepeatedly (cRSID_C64instance *C64) {

 static byte i; static unsigned char String[32];
 static SDL_Rect BackGroundRectangle;


 BackGroundRectangle.x=0; BackGroundRectangle.y=SID1INFO_Y; BackGroundRectangle.w=WINWIDTH; BackGroundRectangle.h=WINHEIGHT-SID1INFO_Y;
 SDL_FillRect(Screen, &BackGroundRectangle, MARGIN_COLOR);


 if (!C64->RealSIDmode) sprintf( String, "%.1fx", (C64->VideoStandard<=1? 19656.0:17095.0) / C64->FrameCycles ); //, C64->FrameCycles );
 drawCenteredTextField( FRAMESPEEDINFO_X+FRAMESPEEDTITLE_WIDTH, FRAMESPEEDINFO_Y, SPEEDINFOFIELD_WIDTH, (!C64->RealSIDmode)? String:(unsigned char*)"?" );


 drawFieldTitle( SID1INFO_X, SID1INFO_Y, VALUETITLE_WIDTH, "SID1:");
  sprintf( String, "$%4.4X,%d(%c)", C64->SID[1].BaseAddress, C64->SID[1].ChipModel, ChannelChar[C64->SID[1].Channel] );
  drawTextField( SID1INFO_X+VALUETITLE_WIDTH, SID1INFO_Y, SIDINFOFIELD_WIDTH, String ); //if(C64->SIDchipCount==1) ;
 drawVUmeter( SCOPE1_X, SCOPE1_Y, SCOPE_WIDTH, SCOPE_HEIGHT, C64->SID[1].Level>>8 ); //, SCOPE_BGCOLOR, SCOPE_FGCOLOR );


 if (C64->SID[2].BaseAddress) {
  drawFieldTitle( SID2INFO_X, SID2INFO_Y, VALUETITLE_WIDTH, "SID2:");
   sprintf( String, "$%4.4X,%d(%c)", C64->SID[2].BaseAddress, C64->SID[2].ChipModel, ChannelChar[C64->SID[2].Channel] );
   drawTextField( SID2INFO_X+VALUETITLE_WIDTH, SID2INFO_Y, SIDINFOFIELD_WIDTH, String );
  drawVUmeter( SCOPE2_X, SCOPE2_Y, SCOPE_WIDTH, SCOPE_HEIGHT, C64->SID[2].Level>>8 ); //, SCOPE_BGCOLOR, SCOPE_FGCOLOR );
 }

 if (C64->SID[3].BaseAddress) {
  drawFieldTitle( SID3INFO_X, SID3INFO_Y, VALUETITLE_WIDTH, "SID3:");
   sprintf( String, "$%4.4X,%d(%c)", C64->SID[3].BaseAddress, C64->SID[3].ChipModel, ChannelChar[C64->SID[3].Channel] );
   drawTextField( SID3INFO_X+VALUETITLE_WIDTH, SID3INFO_Y, SIDINFOFIELD_WIDTH, String );
  drawVUmeter( SCOPE3_X, SCOPE3_Y, SCOPE_WIDTH, SCOPE_HEIGHT, C64->SID[3].Level>>8 ); //, SCOPE_BGCOLOR, SCOPE_FGCOLOR );
 }

 if (C64->SID[4].BaseAddress) {
  drawFieldTitle( SID4INFO_X, SID4INFO_Y, VALUETITLE_WIDTH, "SID4:");
   sprintf( String, "$%4.4X,%d(%c)", C64->SID[4].BaseAddress, C64->SID[4].ChipModel, ChannelChar[C64->SID[4].Channel] );
   drawTextField( SID4INFO_X+VALUETITLE_WIDTH, SID4INFO_Y, SIDINFOFIELD_WIDTH, String );
  drawVUmeter( SCOPE4_X, SCOPE4_Y, SCOPE_WIDTH, SCOPE_HEIGHT, C64->SID[4].Level>>8 ); //, SCOPE_BGCOLOR, SCOPE_FGCOLOR );
 }


 drawHorizontalSeparator ( MARGIN_THICKNESS, SID3INFO_Y+TEXTFIELD_PADDING-1, WINWIDTH-MARGIN_THICKNESS);


 PushButtonTexts[1] = C64->Paused ? "\x1F" : "\x1D";
 PushButtonTexts[5] = C64->Stereo ? "mo" : "ste";
 for (i=0; i<PUSHBUTTON_AMOUNT; ++i) {
  drawButton( PushButtonX[i] = CONTROLS_X + PUSHBUTTON_PADDING*i + PushButtonSeparation[i], CONTROLS_Y, PUSHBUTTON_WIDTH, PUSHBUTTON_HEIGHT, PushButtonTexts[i], PressedButton==i+1 );
 }

 drawFieldTitle( PLAYTIME_X-1, PLAYTIME_Y-TEXTFIELD_PADDING+6, PLAYTIME_WIDTH, "Time:");
  sprintf ( String, "%2.2d:%2.2d", C64->PlayTime/60, C64->PlayTime%60 );
  drawTextField( PLAYTIME_X, PLAYTIME_Y, PLAYTIME_WIDTH, String );

 drawPotMeter ( POTMETER_X, POTMETER_Y, C64->MainVolume, "Volume", VALUEMODE_PERCENTAGE );

}